/* ===== CONFIG: yahan apni details bharo ===== */
const CFG={wa:"918058144989",email:"hello@chyarakani.com",sheetUrl:"",/*Google Apps Script web-app URL*/formEmail:"",/*formsubmit.co ke liye email*/payLink:"",rzpKey:"",/*Razorpay Key ID rzp_live_xxx*/paypal:"",/*PayPal.Me username*//*Razorpay/Stripe payment link*/tawk:"",/*PROPERTYID/WIDGETID*/rate:88};
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
addEventListener("load",()=>{const p=$("#pre");p&&setTimeout(()=>{p.style.opacity=0;setTimeout(()=>p.remove(),1000)},900)});
addEventListener("scroll",()=>$("header").classList.toggle("s",scrollY>40));
$("#mb").onclick=()=>$("nav").classList.toggle("on");
$$(".rv").forEach(el=>{const io=new IntersectionObserver(e=>{if(e[0].isIntersecting){el.classList.add("on");io.disconnect()}},{threshold:.1});io.observe(el)});
const wa=t=>"https://wa.me/"+CFG.wa+"?text="+encodeURIComponent(t);
$("#wa").href=wa("Hello Chyarakani Atelier, I am interested in: "+location.href);
$$("[data-wa]").forEach(a=>a.href=wa(a.dataset.wa+" "+location.href));
let cur=localStorage.cur||((Intl.DateTimeFormat().resolvedOptions().timeZone||"").startsWith("Asia/Kolkata")?"INR":"USD");
const fmt=n=>cur=="INR"?"₹"+n.toLocaleString("en-IN"):"$"+Math.round(n/CFG.rate).toLocaleString("en-US");
function pr(){const b=$("#price");if(!b)return;const m=$(".fl .on[data-m]");b.textContent=fmt(+m.dataset.p)+" + shipping";$("#adv").textContent="Advance to reserve (20%): "+fmt(Math.round(+m.dataset.p*.2))+". Balance before dispatch.";$("#stone").value=m.dataset.m}
$$("[data-m]").forEach(b=>b.onclick=()=>{$$("[data-m]").forEach(x=>x.classList.remove("on"));b.classList.add("on");pr()});
$$("[data-c]").forEach(b=>{b.classList.toggle("on",b.dataset.c==cur);b.onclick=()=>{cur=b.dataset.c;localStorage.cur=cur;$$("[data-c]").forEach(x=>x.classList.toggle("on",x.dataset.c==cur));pr()}});pr();
async function send(d){const body=JSON.stringify(d);
 if(CFG.sheetUrl)fetch(CFG.sheetUrl,{method:"POST",mode:"no-cors",body}).catch(()=>{});
 if(CFG.formEmail)fetch("https://formsubmit.co/ajax/"+CFG.formEmail,{method:"POST",headers:{"Content-Type":"application/json"},body}).catch(()=>{});}
$$("form[data-lead]").forEach(f=>f.onsubmit=e=>{e.preventDefault();const d=Object.fromEntries(new FormData(f));d.page=location.href;send(d);
 const t="Private quote request\n"+Object.entries(d).map(([k,v])=>k+": "+v).join("\n");
 f.innerHTML='<p class="sm">Thank you</p><p>Our atelier will reply within 24 hours. Opening WhatsApp...</p>';setTimeout(()=>open(wa(t),"_blank"),900)});
const es=$("#est");es&&(es.onchange=()=>$("#estr").textContent=es.value?"Ships to "+es.value+" in 15 days, packed in a custom wooden crate with full insurance.":"");
let shown=sessionStorage.ex;document.addEventListener("mouseout",e=>{if(e.clientY<5&&!shown){shown=sessionStorage.ex=1;$("#ex").classList.add("on")}});
$("#xc")&&($("#xc").onclick=()=>$("#ex").classList.remove("on"));
$("#lb")&&($("#lb").onsubmit=e=>{e.preventDefault();send({type:"lookbook",email:e.target.email.value});$("#ex div").innerHTML='<p class="sm">Thank you</p><p>The 2026 Lookbook is on its way to your inbox.</p>'});
if(CFG.tawk){const s=document.createElement("script");s.async=1;s.src="https://embed.tawk.to/"+CFG.tawk;document.body.appendChild(s)}

const F={};$$("[data-k]").forEach(b=>b.onclick=()=>{const k=b.dataset.k;F[k]=b.dataset.v||"";$$('[data-k="'+k+'"]').forEach(x=>x.classList.toggle("on",x==b));$$(".card").forEach(c=>c.style.display=Object.entries(F).every(([k,v])=>!v||c.dataset[k]==v)?"":"none")});

if(CFG.rzpKey){const s=document.createElement("script");s.src="https://checkout.razorpay.com/v1/checkout.js";document.head.appendChild(s)}
const pay=$("#pay");if(pay)pay.onclick=()=>{const m=$(".fl .on[data-m]"),n=$("h1").textContent,adv=Math.round(+m.dataset.p*.2);
 if(cur=="USD"&&CFG.paypal)return open("https://www.paypal.com/paypalme/"+CFG.paypal+"/"+Math.round(adv/CFG.rate)+"USD","_blank");
 if(CFG.rzpKey&&window.Razorpay)return new Razorpay({key:CFG.rzpKey,amount:adv*100,currency:"INR",name:"Chyarakani",description:n+" ("+m.dataset.m+") 20% advance",theme:{color:"#C9A86A"},handler:r=>{send({type:"payment",product:n,material:m.dataset.m,payment_id:r.razorpay_payment_id,amount_inr:adv});open(wa("Advance paid for "+n+". Razorpay ID: "+r.razorpay_payment_id),"_blank")}}).open();
 if(CFG.payLink)return open(CFG.payLink,"_blank");
 open(wa("I would like to reserve "+n+" ("+m.dataset.m+") with a prepaid advance."),"_blank")};

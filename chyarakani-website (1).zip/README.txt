CHYARAKANI - upload guide
GITHUB PAGES: 1) zip ko pehle apne computer par EXTRACT karo. Zip file ko repo mein upload mat karo. 2) Repo mein index.html root par dikhna chahiye (kisi folder ke andar nahi). 3) Settings > Pages > Source: "Deploy from a branch" > Branch: main, Folder: /(root) > Save. 1-3 minute baad link milega.
HOSTINGER: File Manager > public_html: purani files delete karo, extract ki hui saari files (.htaccess samet) upload karo.
PAYMENT: assets/app.js ke top CFG mein rzpKey (Razorpay Key ID) aur paypal (PayPal.Me username) bharo.
